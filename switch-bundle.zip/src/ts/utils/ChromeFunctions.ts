export function set_badge_text(text:string) {
	chrome.browserAction.setBadgeText({text: text});
}




