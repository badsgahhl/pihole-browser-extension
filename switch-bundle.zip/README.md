# Switch-for-PiHole Chrome

This is a small project to revive the project of Yoder Spencer.
https://github.com/Spencer-Yoder/Remote-Switch-for-Pi-Hole-Chrome	


This is not an official Pi-Hole application.
Pi-hole® is a registered trademark of Pi-hole LLC” or “FTLDNS™ is a trademark of Pi-hole LLC
