# Remote-Switch-for-Pi-Hole-Chrome

This is a small project to revive the project of Yoder Spencer.
https://github.com/Spencer-Yoder/Remote-Switch-for-Pi-Hole-Chrome	


Remote Switch for Pi-Hole to enable and disable the server with the specified time provide by the user without having to open a new tab. No other installs are required.

Select the amount of time you want to disable Pi-Hole for and press Disable. When it is disabled you are enable it by the button.
You can set the max off time in the options page.



This is not an official Pi-Hole application.
Pi-hole® is a registered trademark of Pi-hole LLC” or “FTLDNS™ is a trademark of Pi-hole LLC
